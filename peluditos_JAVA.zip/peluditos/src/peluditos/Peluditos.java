package peluditos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Peluditos {

    private static final String DB_URL = "jdbc:mysql://192.168.10.19/peluditos";
    private static final String DB_USER = "politecnico";
    private static final String DB_PASSWORD = "123456";

    public static void main(String[] args) {
        try {
            // Establecer la conexión con la base de datos
            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Intentar iniciar sesión con un límite de intentos
            boolean inicioSesionExitoso = intentarInicioSesion(connection, 3);

            if (inicioSesionExitoso) {
                // Mostrar el menú principal si la autenticación es exitosa
                mostrarMenuPrincipal(connection);
            } else {
                System.out.println("Número máximo de intentos alcanzado. Saliendo de la aplicación.");
            }

        } catch (SQLException e) {  
            e.printStackTrace();
        }
    }

    private static boolean intentarInicioSesion(Connection connection, int intentosRestantes) {
        Scanner scanner = new Scanner(System.in);

        for (int i = 0; i < intentosRestantes; i++) {
            System.out.print("Usuario: ");
            String usuario = scanner.nextLine();
            System.out.print("Contraseña: ");
            String contrasena = scanner.nextLine();

            // Verificar credenciales (puedes implementar lógica adicional aquí según tus necesidades)
            if ("politecnico".equals(usuario) && "123456".equals(contrasena)) {
                return true; // Credenciales correctas
            } else {
                System.out.println(" ");
                System.out.println("Inicio de sesión fallido. Intentos restantes: " + (intentosRestantes - i - 1));
                System.out.println(" ");
            }
        }

        return false; // No se pudo iniciar sesión después de múltiples intentos
    }

    private static void mostrarMenuPrincipal(Connection connection) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println(" ");
            System.out.println("POLITECNICO INTERNACIONAL | PROGRAMACION II");
            System.out.println(" ");
            System.out.println("Sistema de información para la gestión de Clientes, Empleados, Mascotas, Productos.");
            System.out.println(" ");
            System.out.println("Samantha y sus peluditos - Menú Principal");
            System.out.println(" ");
            // Mostrar las opciones disponibles
            System.out.println(" 1. GESTION DE CLIENTES");
            System.out.println(" 2. GESTION DE EMPLEADOS");
            System.out.println(" 3. GESTION DE MASCOTAS");
            System.out.println(" 4. GESTION DE PRODUCTO");
            System.out.println(" 5. SALIR DE LA APP");
            System.out.println(" ");
            System.out.println("CREDITOS");
            System.out.println("Desarrollado por: David Sebastian Enciso - david.enciso@pi.edu.co, Cristian De Los Rios - cristian.de.los.rios@pi.edu.co y Nicole Pajarito - nicole.pajarito@pi.edu.co");
            System.out.println("Samantha y sus peluditos | Bogotá D.C, Colombia | 2023");
            System.out.println(" ");
            System.out.print("Selecciona una opción: ");
            System.out.println(" ");

            int opcionMenuPrincipal = scanner.nextInt();
            scanner.nextLine();

            switch (opcionMenuPrincipal) {
                case 1:
                    menuClientes(connection, scanner);
                    break;
                case 2:
                    menuEmpleados(connection, scanner);
                    break;
                case 3:
                    menuMascotas(connection, scanner);
                    break;
                case 4:
                    menuProductos(connection, scanner);
                    break;
                case 5:
                    System.out.println("Saliendo de la aplicación.");
                    System.exit(0);
                default:
                    System.out.println("Opción no válida. Inténtalo de nuevo.");
            }
        }
    }


    private static void menuClientes(Connection connection, Scanner scanner) {
        while (true) {
            System.out.println(" ");
            System.out.println("1. Ingresar Cliente");
            System.out.println("2. Eliminar Cliente");
            System.out.println("3. Consultar Cliente");
            System.out.println("4. Actualizar Cliente");
            System.out.println("5. Volver");
            System.out.println("6. Salir");
            System.out.println(" ");
            System.out.print("Selecciona una opción: ");
            System.out.println(" ");
            int opcionClientes = scanner.nextInt();
            scanner.nextLine();

            switch (opcionClientes) {
                case 1:
                    ingresarCliente(connection, scanner);
                    break;
                case 2:
                    eliminarCliente(connection, scanner);
                    break;
                case 3:
                    consultarClientes(connection);
                    break;
                case 4:
                    actualizarCliente(connection, scanner);
                    break;
                case 5:
                    return; // Regresar al menú principal
                case 6:
                    System.out.println("Saliendo de la aplicación.");
                    System.exit(0);
                default:
                    System.out.println("Opción no válida. Inténtalo de nuevo.");
            }
        }
    }

    private static void menuEmpleados(Connection connection, Scanner scanner) {
        while (true) {
            System.out.println(" ");
            System.out.println("1. Ingresar Empleado");
            System.out.println("2. Eliminar Empleado");
            System.out.println("3. Consultar Empleado");
            System.out.println("4. Actualizar Empleado");
            System.out.println("5. Volver");
            System.out.println("6. Salir");
            System.out.println(" ");
            System.out.print("Selecciona una opción: ");
            System.out.println(" ");
            int opcionEmpleados = scanner.nextInt();
            scanner.nextLine();

            switch (opcionEmpleados) {
                case 1:
                    ingresarEmpleado(connection, scanner);
                    break;
                case 2:
                    eliminarEmpleado(connection, scanner);
                    break;
                case 3:
                    consultarEmpleados(connection);
                    break;
                case 4:
                    actualizarEmpleado(connection, scanner);
                    break;
                case 5:
                    return; // Regresar al menú principal
                case 6:
                    System.out.println("Saliendo de la aplicación.");
                    System.exit(0);
                default:
                    System.out.println("Opción no válida. Inténtalo de nuevo.");
            }
        }
    }
    
    private static void menuMascotas(Connection connection, Scanner scanner) {
    while (true) {
        System.out.println(" ");
        System.out.println("1. Ingresar Mascota");
        System.out.println("2. Eliminar Mascota");
        System.out.println("3. Consultar Mascota");
        System.out.println("4. Actualizar Mascota");
        System.out.println("5. Volver");
        System.out.println("6. Salir");
        System.out.println(" ");
        System.out.print("Selecciona una opción: ");
        System.out.println(" ");
        int opcionMascotas = scanner.nextInt();
        scanner.nextLine();

        switch (opcionMascotas) {
            case 1:
                ingresarMascota(connection, scanner);
                break;
            case 2:
                eliminarMascota(connection, scanner);
                break;
            case 3:
                consultarMascota(connection);
                break;
            case 4:
                actualizarMascota(connection, scanner);
                break;
            case 5:
                return; // Regresar al menú principal
            case 6:
                System.out.println("Saliendo de la aplicación.");
                System.exit(0);
            default:
                System.out.println("Opción no válida. Inténtalo de nuevo.");
        }
    }
}

private static void menuProductos(Connection connection, Scanner scanner) {
    while (true) {
        System.out.println(" ");
        System.out.println("1. Ingresar Producto");
        System.out.println("2. Eliminar Producto");
        System.out.println("3. Consultar Producto");
        System.out.println("4. Actualizar Producto");
        System.out.println("5. Volver");
        System.out.println("6. Salir");
        
        System.out.print("Selecciona una opción: ");
        System.out.println(" ");
        int opcionProductos = scanner.nextInt();
        scanner.nextLine();

        switch (opcionProductos) {
            case 1:
                ingresarProducto(connection, scanner);
                break;
            case 2:
                eliminarProducto(connection, scanner);
                break;
            case 3:
                consultarProducto(connection);
                break;
            case 4:
                actualizarProducto(connection, scanner);
                break;
            case 5:
                return; // Regresar al menú principal
            case 6:
                System.out.println("Saliendo de la aplicación.");
                System.exit(0);
            default:
                System.out.println("Opción no válida. Inténtalo de nuevo.");
        }
    }
}


    // Método para ingresar un cliente en la base de datos
    private static void ingresarCliente(Connection connection, Scanner scanner) {
        try {
            System.out.print("Nombre del cliente: ");
            String nombre = scanner.nextLine();
            System.out.print("Edad: ");
            int edad = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Estado Civil: ");
            String estadoCivil = scanner.nextLine();

            String insertQuery = "INSERT INTO Clientes (Nombre, Edad, EstadoCivil) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(1, nombre);
            preparedStatement.setInt(2, edad);
            preparedStatement.setString(3, estadoCivil);
            int rowCount = preparedStatement.executeUpdate();

            if (rowCount > 0) {
                System.out.println("Cliente ingresado con éxito.");
            } else {
                System.out.println("Error al ingresar el cliente.");
            }
        } catch (SQLException e) {
        }
    }

    // Método para eliminar un cliente en la base de datos
    private static void eliminarCliente(Connection connection, Scanner scanner) {
        try {
            System.out.print("ID del cliente a eliminar: ");
            int clienteID = scanner.nextInt();

            String deleteQuery = "DELETE FROM Clientes WHERE ClienteID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
            preparedStatement.setInt(1, clienteID);
            int rowCount = preparedStatement.executeUpdate();

            if (rowCount > 0) {
                System.out.println("Cliente eliminado con éxito.");
            } else {
                System.out.println("No se encontró ningún cliente con ese ID.");
            }
        } catch (SQLException e) {
        }
    }

    // Método para consultar un cliente en la base de datos
    private static void consultarClientes(Connection connection) {
        try {
            String selectQuery = "SELECT ClienteID, Nombre, Edad, EstadoCivil FROM Clientes";
            PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int clienteID = resultSet.getInt("ClienteID");
                String nombre = resultSet.getString("Nombre");
                int edad = resultSet.getInt("Edad");
                String estadoCivil = resultSet.getString("EstadoCivil");
                System.out.println("ID: " + clienteID + ", Nombre: " + nombre + ", Edad: " + edad + ", Estado Civil: " + estadoCivil);
            }
        } catch (SQLException e) {
        }
    }

    // Método para actualizar un cliente en la base de datos
    private static void actualizarCliente(Connection connection, Scanner scanner) {
        try {
            System.out.print("ID del cliente a actualizar: ");
            int clienteID = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Nuevo nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Nueva edad: ");
            int edad = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Nuevo estado civil: ");
            String estadoCivil = scanner.nextLine();

            String updateQuery = "UPDATE Clientes SET Nombre = ?, Edad = ?, EstadoCivil = ? WHERE ClienteID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setString(1, nombre);
            preparedStatement.setInt(2, edad);
            preparedStatement.setString(3, estadoCivil);
            preparedStatement.setInt(4, clienteID);
            int rowCount = preparedStatement.executeUpdate();

            if (rowCount > 0) {
                System.out.println("Cliente actualizado con éxito.");
            } else {
                System.out.println("No se encontró ningún cliente con ese ID.");
            }
        } catch (SQLException e) {
        }
    }

    // Método para ingresar un empleado en la base de datos
    private static void ingresarEmpleado(Connection connection, Scanner scanner) {
        try {
            System.out.print("Nombre del empleado: ");
            String nombre = scanner.nextLine();
            System.out.print("Código de empleado: ");
            String codigoEmpleado = scanner.nextLine();
            System.out.print("Área: ");
            String area = scanner.nextLine();
            System.out.print("Sede: ");
            String sede = scanner.nextLine();

            String insertQuery = "INSERT INTO Empleados (Nombre, CodigoEmpleado, Area, Sede) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(1, nombre);
            preparedStatement.setString(2, codigoEmpleado);
            preparedStatement.setString(3, area);
            preparedStatement.setString(4, sede);
            int rowCount = preparedStatement.executeUpdate();

            if (rowCount > 0) {
                System.out.println("Empleado ingresado con éxito.");
            } else {
                System.out.println("Error al ingresar el empleado.");
            }
        } catch (SQLException e) {
        }
    }
    
    // Método para eliminar un empleado en la base de datos
    private static void eliminarEmpleado(Connection connection, Scanner scanner) {
        try {
            System.out.print("ID del empleado a eliminar: ");
            int empleadoID = scanner.nextInt();

            String deleteQuery = "DELETE FROM Empleados WHERE EmpleadoID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
            preparedStatement.setInt(1, empleadoID);
            int rowCount = preparedStatement.executeUpdate();

            if (rowCount > 0) {
                System.out.println("Empleado eliminado con éxito.");
            } else {
                System.out.println("No se encontró ningún empleado con ese ID.");
            }
        } catch (SQLException e) {
        }
    }
    
    // Método para consultar un empleado en la base de datos
    private static void consultarEmpleados(Connection connection) {
        try {
            String selectQuery = "SELECT EmpleadoID, Nombre, CodigoEmpleado, Area, Sede FROM Empleados";
            PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int empleadoID = resultSet.getInt("EmpleadoID");
                String nombre = resultSet.getString("Nombre");
                String codigoEmpleado = resultSet.getString("CodigoEmpleado");
                String area = resultSet.getString("Area");
                String sede = resultSet.getString("Sede");
                System.out.println("ID: " + empleadoID + ", Nombre: " + nombre + ", Código de Empleado: " + codigoEmpleado + ", Área: " + area + ", Sede: " + sede);
            }
        } catch (SQLException e) {
        }
    }

    // Método para actualizar un empleado en la base de datos
    private static void actualizarEmpleado(Connection connection, Scanner scanner) {
        try {
            System.out.print("ID del empleado a actualizar: ");
            int empleadoID = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Nuevo nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Nuevo código de empleado: ");
            String codigoEmpleado = scanner.nextLine();
            System.out.print("Nueva área: ");
            String area = scanner.nextLine();
            System.out.print("Nueva sede: ");
            String sede = scanner.nextLine();

            String updateQuery = "UPDATE Empleados SET Nombre = ?, CodigoEmpleado = ?, Area = ?, Sede = ? WHERE EmpleadoID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setString(1, nombre);
            preparedStatement.setString(2, codigoEmpleado);
            preparedStatement.setString(3, area);
            preparedStatement.setString(4, sede);
            preparedStatement.setInt(5, empleadoID);
            int rowCount = preparedStatement.executeUpdate();

            if (rowCount > 0) {
                System.out.println("Empleado actualizado con éxito.");
            } else {
                System.out.println("No se encontró ningún empleado con ese ID.");
            }
        } catch (SQLException e) {
        }
    }
// Método para ingresar una mascota en la base de datos
private static void ingresarMascota(Connection connection, Scanner scanner) {
    try {
        System.out.print("ID mascota: ");
        String idMascota = scanner.nextLine();
        System.out.print("Nombre Mascota: ");
        String nombre = scanner.nextLine();
        System.out.print("Raza: ");
        String raza = scanner.nextLine();
        System.out.print("Color: ");
        String color = scanner.nextLine();
        System.out.print("Nombre del Dueño: ");
        String nombreDueno = scanner.nextLine();

        String insertQuery = "INSERT INTO Mascotas (IdMascota, Nombre, Raza, Color, NombreDueno) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
        preparedStatement.setString(1, idMascota);
        preparedStatement.setString(2, nombre);
        preparedStatement.setString(3, raza);
        preparedStatement.setString(4, color);
        preparedStatement.setString(5, nombreDueno);
        int rowCount = preparedStatement.executeUpdate();

        if (rowCount > 0) {
            System.out.println("Mascota ingresada con éxito.");
        } else {
            System.out.println("Error al ingresar la mascota.");
        }
    } catch (SQLException e) {
        e.printStackTrace(); // Imprime detalles del error
    }
}

// Método para eliminar una mascota en la base de datos
private static void eliminarMascota(Connection connection, Scanner scanner) {
    try {
        System.out.print("ID de la mascota a eliminar: ");
        String idMascota = scanner.nextLine();

        String deleteQuery = "DELETE FROM Mascotas WHERE IdMascota = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
        preparedStatement.setString(1, idMascota);
        int rowCount = preparedStatement.executeUpdate();

        if (rowCount > 0) {
            System.out.println("Mascota eliminada con éxito.");
        } else {
            System.out.println("No se encontró ninguna mascota con ese ID.");
        }
    } catch (SQLException e) {
        e.printStackTrace(); // Imprime detalles del error
    }
}

// Método para consultar las mascotas en la base de datos
private static void consultarMascota(Connection connection) {
    try {
        String selectQuery = "SELECT IdMascota, Nombre, Raza, Color, NombreDueno FROM Mascotas";
        PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);
        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()) {
            String idMascota = resultSet.getString("IdMascota");
            String nombre = resultSet.getString("Nombre");
            String raza = resultSet.getString("Raza");
            String color = resultSet.getString("Color");
            String nombreDueno = resultSet.getString("NombreDueno");
            System.out.println("ID: " + idMascota + ", Nombre: " + nombre + ", Raza: " + raza + ", Color: " + color + ", Nombre del Dueño: " + nombreDueno);
        }
    } catch (SQLException e) {
        e.printStackTrace(); // Imprime detalles del error
    }
}

// Método para actualizar una mascota en la base de datos
private static void actualizarMascota(Connection connection, Scanner scanner) {
    try {
        System.out.print("ID de la mascota a actualizar: ");
        String idMascota = scanner.nextLine();

        System.out.print("Nuevo nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Nueva raza: ");
        String raza = scanner.nextLine();
        System.out.print("Nuevo color: ");
        String color = scanner.nextLine();
        System.out.print("Nuevo nombre del dueño: ");
        String nombreDueno = scanner.nextLine();

        String updateQuery = "UPDATE Mascotas SET Nombre = ?, Raza = ?, Color = ?, NombreDueno = ? WHERE IdMascota = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
        preparedStatement.setString(1, nombre);
        preparedStatement.setString(2, raza);
        preparedStatement.setString(3, color);
        preparedStatement.setString(4, nombreDueno);
        preparedStatement.setString(5, idMascota);
        int rowCount = preparedStatement.executeUpdate();

        if (rowCount > 0) {
            System.out.println("Mascota actualizada con éxito.");
        } else {
            System.out.println("No se encontró ninguna mascota con ese ID.");
        }
    } catch (SQLException e) {
        e.printStackTrace(); // Imprime detalles del error
    }
}

// Método para ingresar un producto en la base de datos
private static void ingresarProducto(Connection connection, Scanner scanner) {
    try {
        System.out.print("Nombre del producto: ");
        String nombreProducto = scanner.nextLine();
        System.out.print("Precio: ");
        double precio = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Cantidad en stock: ");
        int cantidadStock = scanner.nextInt();
        scanner.nextLine();
        System.out.print("¿Disponible? (true/false): ");
        boolean disponible = scanner.nextBoolean();

        String insertQuery = "INSERT INTO Productos (nombreproducto, Precio, CantidadStock, disponible) VALUES (?, ?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
        preparedStatement.setString(1, nombreProducto);
        preparedStatement.setDouble(2, precio);
        preparedStatement.setInt(3, cantidadStock);
        preparedStatement.setBoolean(4, disponible);
        int rowCount = preparedStatement.executeUpdate();

        if (rowCount > 0) {
            System.out.println("Producto ingresado con éxito.");
        } else {
            System.out.println("Error al ingresar el producto.");
        }
    } catch (SQLException e) {
    }
}

// Método para eliminar un producto en la base de datos
private static void eliminarProducto(Connection connection, Scanner scanner) {
    try {
        System.out.print("ID del producto a eliminar: ");
        int productoID = scanner.nextInt();

        String deleteQuery = "DELETE FROM Productos WHERE idproducto = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
        preparedStatement.setInt(1, productoID);
        int rowCount = preparedStatement.executeUpdate();

        if (rowCount > 0) {
            System.out.println("Producto eliminado con éxito.");
        } else {
            System.out.println("No se encontró ningún producto con ese ID.");
        }
    } catch (SQLException e) {
    }
}

// Método para consultar un producto en la base de datos
private static void consultarProducto(Connection connection) {
    try {
        String selectQuery = "SELECT idproducto, nombreproducto, Precio, CantidadStock, disponible FROM Productos";
        PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);
        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()) {
            int productoID = resultSet.getInt("idproducto");
            String nombreProducto = resultSet.getString("nombreproducto");
            double precio = resultSet.getDouble("Precio");
            int cantidadStock = resultSet.getInt("CantidadStock");
            boolean disponible = resultSet.getBoolean("disponible");
            System.out.println("ID: " + productoID + ", Nombre: " + nombreProducto + ", Precio: " + precio + ", Cantidad en Stock: " + cantidadStock + ", Disponible: " + disponible);
        }
    } catch (SQLException e) {
    }
}

// Método para actualizar un producto en la base de datos
private static void actualizarProducto(Connection connection, Scanner scanner) {
    try {
        System.out.print("ID del producto a actualizar: ");
        int productoID = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Nuevo nombre del producto: ");
        String nombreProducto = scanner.nextLine();
        System.out.print("Nuevo precio: ");
        double precio = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Nueva cantidad en stock: ");
        int cantidadStock = scanner.nextInt();
        scanner.nextLine();
        System.out.print("¿Nuevo estado de disponibilidad? (true/false): ");
        boolean disponible = scanner.nextBoolean();

        String updateQuery = "UPDATE Productos SET nombreproducto = ?, Precio = ?, CantidadStock = ?, disponible = ? WHERE idproducto = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
        preparedStatement.setString(1, nombreProducto);
        preparedStatement.setDouble(2, precio);
        preparedStatement.setInt(3, cantidadStock);
        preparedStatement.setBoolean(4, disponible);
        preparedStatement.setInt(5, productoID);
        int rowCount = preparedStatement.executeUpdate();

        if (rowCount > 0) {
            System.out.println("Producto actualizado con éxito.");
        } else {
            System.out.println("No se encontró ningún producto con ese ID.");
        }
    } catch (SQLException e) {
    }
}
}