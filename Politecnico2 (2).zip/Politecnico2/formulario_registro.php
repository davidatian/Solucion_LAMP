<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = "example_user";
    $password = "password";
    $database = "example_database";
    $table = "users";

    try {
        $db = new PDO("mysql:host=localhost;dbname=$database", $user, $password);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $username = $_POST['username'];
        $password = $_POST['password'];

        // Hash de la contraseña
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Insertar usuario en la base de datos
        $query = $db->prepare("INSERT INTO $table (username, password) VALUES (:username, :password)");
        $query->bindParam(':username', $username);
        $query->bindParam(':password', $hashedPassword);
        $query->execute();

        echo '<script>alert("Usuario registrado exitosamente.");</script>';

    } catch (PDOException $e) {
        echo '<script>alert("Error de conexión a la base de datos: ' . $e->getMessage() . '");</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <style>
        /* Estilos del formulario */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background-color: rgb(11, 161, 111); /* Green */
            color: #000000;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
            margin: auto;
            margin-top: 130px; /* Ajuste el margen superior según sea necesario */
        
        }
        label {
            display: block;
            margin-bottom: 8px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
        }

        button {
            background-color: #333;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #555;
        }

        header {
            background-color: #ddd;
            padding: 10px;
            text-align: center;
        }

        /* Estilos de la barra de navegación */
        nav {
            background-color: #333;
            overflow: hidden;
            color: white;
            text-align: center;
            padding: 14px 0;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000; /* Asegura que la barra de navegación esté por encima de otros elementos */
        }

        nav a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        nav a:hover {
            background-color: #ddd;
            color: black;
        }

       

        footer {
            background-color: #fd9c9c;
            padding: 10px;
            text-align: center;
            margin-top: 50px; /* Mueve el footer al fondo */
            width: 100%;
        }
    </style>
</head>

<body>

<!-- Navbar -->
<nav>
    <a href="index.html">Inicio</a>
    <a href="formulario_registro.php">Registro de usuarios</a>
    <a href="iniciar_sesion.php">Login</a>
</nav>
 
<form method="post" action="">
    <h2>Registro de Usuario</h2>

    <label for="username">Usuario:</label>
    <input type="text" id="username" name="username" required>

    <label for="password">Contraseña:</label>
    <input type="password" id="password" name="password" required>

    <button type="submit">Registrarse</button>
</form>

<!-- Footer -->
<footer class="container-fluid bg-4 text-center">
<div style="text-align: center;">
    <img src="Images/logo.png" class="img-responsive margin" style="display: inline-block; width: 10%;" alt="Image">
    </div>
    <p>Creado por: Tecnik Technology Company Proyecto Samantha y sus peluditos</p> 
    <p>Politecnico Internacional - nicole.pajarito@pi.edu.co - david.enciso@pi.edu.co - cristian.de.los.rios@pi.edu.co Bogota D.C - 2023</p> 
</footer>

</body>
</html>