<?php
session_start();

// Verificar si el usuario ya está autenticado, redirigir a Todolist si es así
if (isset($_SESSION['user_id'])) {
    header("Location: crud2.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = "example_user";
    $password = "password";
    $database = "example_database";
    $table = "users";

    try {
        $db = new PDO("mysql:host=localhost;dbname=$database", $user, $password);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Obtener datos del formulario
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Consulta para obtener el usuario
        $query = $db->prepare("SELECT * FROM $table WHERE username = :username");
        $query->bindParam(':username', $username);
        $query->execute();
        $userRow = $query->fetch(PDO::FETCH_ASSOC);

        // Verificar la contraseña utilizando password_verify
        if ($userRow && password_verify($password, $userRow['password'])) {
            // Credenciales válidas, establecer la sesión y redirigir a Todolist
            $_SESSION['user_id'] = $userRow['user_id'];
            header("Location: crud2.php");
            exit();
        } else {
            $error = "Usuario o contraseña incorrectos";
        }

    } catch (PDOException $e) {
        $error = "Error de conexión a la base de datos";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Acceso</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background-color: rgb(11, 161, 111); /* Green */
            color: #000000;;
        }

        header {
            background-color: #ddd;
            padding: 10px;
            text-align: center;
        }

        /* Estilos de la barra de navegación */
        nav {
            background-color: #333;
            overflow: hidden;
            color: white;
            text-align: center;
            padding: 14px 0;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000; /* Asegura que la barra de navegación esté por encima de otros elementos */
        }

        nav a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        nav a:hover {
            background-color: #ddd;
            color: black;
        }

        form {
         margin-bottom: 15%;
         background-color: #fff;
         padding: 40px;
         border-radius: 8px;
         MARGIN-TOP: 3%;
         box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

        input {
            margin-bottom: 10px;
            padding: 8px;
        }

        button {
            background-color: #4caf50;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

     
        footer {
    background-color: #fd9c9c;
    color: black;
    text-align: center;
    padding: 10px;
    bottom: 0;
    position: fixed;
    width: 100%;
}
    </style>
</head>

<!-- Navbar -->
<nav>
    <a href="index.html">Inicio</a>
    <a href="formulario_registro.php">Registro de usuarios</a>
    <a href="iniciar_sesion.php">Login</a>
</nav>

<body>

<form method="post" action="">
    <h2>Inicio de Sesión</h2>

    <?php
    if (isset($error)) {
        echo "<p style='color: red;'>$error</p>";
    }
    ?>

    <label for="username">Usuario:</label>
    <input type="text" id="username" name="username" required>

    <label for="password">Contraseña:</label>
    <input type="password" id="password" name="password" required>

    <button type="submit">Iniciar Sesión</button>
</form>

<!-- Footer -->
<footer class="container-fluid bg-4 text-center">
   <!-- <p>Bootstrap Theme Made By <a href="https://www.w3schools.com">www.w3schools.com</a></p> -->
   <div style="text-align: center;">
    <img src="Images/logo.png" class="img-responsive margin" style="display: inline-block; width: 10%;" alt="Image">
    </div>
    <p>Creado por: Tecnik Technology Company Proyecto Samantha y sus peluditos</p> 
    <p>Politecnico Internacional - nicole.pajarito@pi.edu.co - david.enciso@pi.edu.co - cristian.de.los.rios@pi.edu.co Bogota D.C - 2023</p> 
  </footer>

</body>
</html>