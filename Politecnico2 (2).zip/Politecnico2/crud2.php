<?php
$user = "example_user";
$password = "password";
$database = "example_database";
$clientTable = "todo_list";
$petTable = "mascotas";

try {
    $db = new PDO("mysql:host=localhost;dbname=$database", $user, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Función para leer y mostrar todos los elementos de la tabla de clientes
    function readClientData($db, $table)
    {
        echo "<h2>Clientes</h2>";
        echo "<table border='1'>";
        echo "<tr><th>Nombre</th><th>Edad</th><th>Estado Civil</th><th>Acciones</th></tr>";
        $query = $db->query("SELECT * FROM $table");
        while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>
                <td>{$row['nombre']}</td>
                <td>{$row['edad']} años</td>
                <td>{$row['estado_civil']}</td>
                <td>
                    <a href='?action=edit&table=todo_list&id={$row['item_id']}'><button>Editar</button></a>
                    <a href='?action=delete&table=todo_list&id={$row['item_id']}'><button>Eliminar</button></a>
                </td>
            </tr>";
        }
        echo "</table>";
    }

    // Función para leer y mostrar todos los elementos de la tabla de mascotas
    function readPetData($db, $table)
    {
        echo "<h2>Mascotas</h2>";
        echo "<table border='1'>";
        echo "<tr><th>ID Mascota</th><th>Nombre</th><th>Raza</th><th>Color</th><th>Nombre del Dueño</th><th>Acciones</th></tr>";
        $query = $db->query("SELECT * FROM $table");
        while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>
                <td>{$row['id_mascota']}</td>
                <td>{$row['nombre']}</td>
                <td>{$row['raza']}</td>
                <td>{$row['color']}</td>
                <td>{$row['nombre_dueno']}</td>
                <td>
                    <a href='?action=edit&table=mascotas&id={$row['item_id']}'><button>Editar</button></a>
                    <a href='?action=delete&table=mascotas&id={$row['item_id']}'><button>Eliminar</button></a>
                </td>
            </tr>";
        }
        echo "</table>";
    }

    // Función para insertar un nuevo cliente en la tabla
    function insertClientData($db, $table, $nombre, $edad, $estadoCivil)
    {
        $stmt = $db->prepare("INSERT INTO $table (nombre, edad, estado_civil) VALUES (:nombre, :edad, :estadoCivil)");
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':edad', $edad, PDO::PARAM_INT);
        $stmt->bindParam(':estadoCivil', $estadoCivil);
        $stmt->execute();
    }

    // Función para insertar una nueva mascota en la tabla
    function insertPetData($db, $table, $idMascota, $nombre, $raza, $color, $nombreDueno)
    {
        $stmt = $db->prepare("INSERT INTO $table (id_mascota, nombre, raza, color, nombre_dueno) 
            VALUES (:idMascota, :nombre, :raza, :color, :nombreDueno)");
        $stmt->bindParam(':idMascota', $idMascota);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':raza', $raza);
        $stmt->bindParam(':color', $color);
        $stmt->bindParam(':nombreDueno', $nombreDueno);
        $stmt->execute();
    }

    // Función para actualizar un cliente en la tabla
    function updateClientData($db, $table, $id, $nombre, $edad, $estadoCivil)
    {
        $stmt = $db->prepare("UPDATE $table SET nombre = :nombre, edad = :edad, estado_civil = :estadoCivil WHERE item_id = :id");
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':edad', $edad, PDO::PARAM_INT);
        $stmt->bindParam(':estadoCivil', $estadoCivil);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
    }

    // Función para actualizar una mascota en la tabla
    function updatePetData($db, $table, $id, $idMascota, $nombre, $raza, $color, $nombreDueno)
    {
        $stmt = $db->prepare("UPDATE $table SET id_mascota = :idMascota, nombre = :nombre, raza = :raza, 
            color = :color, nombre_dueno = :nombreDueno WHERE item_id = :id");
        $stmt->bindParam(':idMascota', $idMascota);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':raza', $raza);
        $stmt->bindParam(':color', $color);
        $stmt->bindParam(':nombreDueno', $nombreDueno);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
    }

    // Función para eliminar un cliente de la tabla
    function deleteClientData($db, $table, $id)
    {
        $stmt = $db->prepare("DELETE FROM $table WHERE item_id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
    }

    // Función para eliminar una mascota de la tabla
    function deletePetData($db, $table, $id)
    {
        $stmt = $db->prepare("DELETE FROM $table WHERE item_id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
    }

    // Manejo de acciones
    if (isset($_GET['action'])) {
        switch ($_GET['action']) {
            case 'delete':
                if (isset($_GET['id']) && isset($_GET['table'])) {
                    if ($_GET['table'] === 'todo_list') {
                        deleteClientData($db, $clientTable, $_GET['id']);
                    } elseif ($_GET['table'] === 'mascotas') {
                        deletePetData($db, $petTable, $_GET['id']);
                    }
                }
                break;
            case 'edit':
                if (isset($_GET['id']) && isset($_GET['table'])) {
                    if ($_GET['table'] === 'todo_list') {
                        $query = $db->prepare("SELECT * FROM $clientTable WHERE item_id = :id");
                        $query->bindParam(':id', $_GET['id']);
                        $query->execute();
                        $row = $query->fetch(PDO::FETCH_ASSOC);
                        echo "<h2>Editar cliente</h2>
                        <form method='post' action=''>
                            <label for='nombre'>Nombre:</label>
                            <input type='text' name='nombre' value='" . $row['nombre'] . "' required>
                            <label for='edad'>Edad:</label>
                            <input type='number' name='edad' value='" . $row['edad'] . "' required>
                            <label for='estado_civil'>Estado Civil:</label>
                            <input type='text' name='estado_civil' value='" . $row['estado_civil'] . "' required>
                            <input type='hidden' name='id' value='" . $row['item_id'] . "'>
                            <input type='hidden' name='table' value='todo_list'>
                            <input type='submit' name='update' value='Actualizar'>
                        </form>";
                    } elseif ($_GET['table'] === 'mascotas') {
                        $query = $db->prepare("SELECT * FROM $petTable WHERE item_id = :id");
                        $query->bindParam(':id', $_GET['id']);
                        $query->execute();
                        $row = $query->fetch(PDO::FETCH_ASSOC);
                        echo "<h2>Editar mascota</h2>
                        <form method='post' action=''>
                            <label for='id_mascota'>ID Mascota:</label>
                            <input type='text' name='id_mascota' value='" . $row['id_mascota'] . "' required>
                            <label for='nombre'>Nombre:</label>
                            <input type='text' name='nombre' value='" . $row['nombre'] . "' required>
                            <label for='raza'>Raza:</label>
                            <input type='text' name='raza' value='" . $row['raza'] . "' required>
                            <label for='color'>Color:</label>
                            <input type='text' name='color' value='" . $row['color'] . "' required>
                            <label for='nombre_dueno'>Nombre del Dueño:</label>
                            <input type='text' name='nombre_dueno' value='" . $row['nombre_dueno'] . "' required>
                            <input type='hidden' name='id' value='" . $row['item_id'] . "'>
                            <input type='hidden' name='table' value='mascotas'>
                            <input type='submit' name='update' value='Actualizar'>
                        </form>";
                    }
                }
                break;
        }
    }

    // Procesamiento del formulario de inserción o actualización
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['insert'])) {
            if ($_POST['table'] === 'todo_list') {
                $nombre = $_POST['nombre'];
                $edad = $_POST['edad'];
                $estadoCivil = $_POST['estado_civil'];
                insertClientData($db, $clientTable, $nombre, $edad, $estadoCivil);
            } elseif ($_POST['table'] === 'mascotas') {
                $idMascota = $_POST['id_mascota'];
                $nombre = $_POST['nombre'];
                $raza = $_POST['raza'];
                $color = $_POST['color'];
                $nombreDueno = $_POST['nombre_dueno'];
                insertPetData($db, $petTable, $idMascota, $nombre, $raza, $color, $nombreDueno);
            }
        } elseif (isset($_POST['update'])) {
            if ($_POST['table'] === 'todo_list') {
                $id = $_POST['id'];
                $nombre = $_POST['nombre'];
                $edad = $_POST['edad'];
                $estadoCivil = $_POST['estado_civil'];
                updateClientData($db, $clientTable, $id, $nombre, $edad, $estadoCivil);
            } elseif ($_POST['table'] === 'mascotas') {
                $id = $_POST['id'];
                $idMascota = $_POST['id_mascota'];
                $nombre = $_POST['nombre'];
                $raza = $_POST['raza'];
                $color = $_POST['color'];
                $nombreDueno = $_POST['nombre_dueno'];
                updatePetData($db, $petTable, $id, $idMascota, $nombre, $raza, $color, $nombreDueno);
            }
        }
    }
} catch (PDOException $e) {
    print "Error!: " . $e->getMessage() . "<br/>";
    die();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Clientes y Mascotas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: rgb(11, 161, 111); /* Green */
            color: #000000;
        }

        nav {
            background-color: #333;
            overflow: hidden;
            color: white;
            text-align: center;
            padding: 14px 0;
        }

        nav a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        nav a:hover {
            background-color: #ddd;
            color: black;
        }

        footer {
         background-color: #fd9c9c;
        color: black;
        text-align: center;
        padding: 10px;
        margin-top: 20px; /* Agregamos un margen superior para separarlo del contenido */
    }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        form {
            width: 80%;
            margin: 20px auto;
        }

        label, input {
            display: block;
            margin: 10px 0;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav>
    <a href="index.html">Inicio</a>
    <a href="?table=todo_list">Gestión de Clientes</a>
    <a href="?table=mascotas">Gestión de Mascotas</a>
</nav>

<!-- Contenido de la página -->
<div style="padding: 16px;">
    <?php
    // Mostrar la lista actualizada después de realizar operaciones CRUD
    if (isset($_GET['table']) && $_GET['table'] === 'mascotas') {
        readPetData($db, $petTable);
    } else {
        readClientData($db, $clientTable);
    }
    ?>

    <!-- Formulario para insertar nuevos clientes o mascotas -->
    <?php
    if (isset($_GET['table']) && $_GET['table'] === 'mascotas') {
        echo "<h2>Agregar nueva mascota</h2>";
    } else {
        echo "<h2>Agregar nuevo cliente</h2>";
    }
    ?>
    <form method="post" action="">
        <table>
            <?php
            if (isset($_GET['table']) && $_GET['table'] === 'mascotas') {
                echo "<tr>
                        <td><label for='id_mascota'>ID Mascota:</label></td>
                        <td><input type='text' name='id_mascota' placeholder='ID Mascota' required></td>
                    </tr>";
            } ?>
            <tr>
                <td><label for="nombre">Nombre:</label></td>
                <td><input type="text" name="nombre" placeholder="Nombre" required></td>
            </tr>
            <?php
            if (!isset($_GET['table']) || $_GET['table'] === 'todo_list') {
                echo "<tr>
                        <td><label for='edad'>Edad:</label></td>
                        <td><input type='number' name='edad' placeholder='Edad' required></td>
                    </tr>
                    <tr>
                        <td><label for='estado_civil'>Estado Civil:</label></td>
                        <td><input type='text' name='estado_civil' placeholder='Estado Civil' required></td>
                    </tr>";
            } elseif ($_GET['table'] === 'mascotas') {
                echo "<tr>
                        <td><label for='raza'>Raza:</label></td>
                        <td><input type='text' name='raza' placeholder='Raza' required></td>
                    </tr>
                    <tr>
                        <td><label for='color'>Color:</label></td>
                        <td><input type='text' name='color' placeholder='Color' required></td>
                    </tr>
                    <tr>
                        <td><label for='nombre_dueno'>Nombre del Dueño:</label></td>
                        <td><input type='text' name='nombre_dueno' placeholder='Nombre del Dueño' required></td>
                    </tr>";
            }
            ?>
        </table>
        <input type="hidden" name="table" value="<?php echo $_GET['table']; ?>">
        <?php
        if (isset($_GET['action']) && $_GET['action'] === 'edit') {
            echo "<input type='hidden' name='id' value='" . $_GET['id'] . "'>";
            echo "<input type='submit' name='update' value='Actualizar'>";
        } else {
            echo "<input type='submit' name='insert' value='Agregar'>";
        }
        ?>
    </form>
</div>

<!-- Footer -->
<footer class="container-fluid bg-4 text-center">
    <div style="text-align: center;">
        <img src="Images/logo.png" class="img-responsive margin" style="display: inline-block; width: 10%;" alt="Image">
    </div>
    <p>Creado por: Tecnik Technology Company Proyecto Samantha y sus peluditos</p>
    <p>Politécnico Internacional - nicole.pajarito@pi.edu.co - david.enciso@pi.edu.co - cristian.de.los.rios@pi.edu.co Bogotá D.C - 2023</p>
</footer>

</body>
</html>